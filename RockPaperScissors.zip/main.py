# ask player what they want to play, choose random response, see
# who wins, announce winner, end game
import random
options = ["Rock", "Paper", "Scissors"]

def play():
  while(True):
    p1 = input("Choose Rock, Paper, or Scissors: ")
    if (p1 == "Rock" or p1 == "Paper" or p1 == "Scissors"):
      break
    else:
      print("That is not an option! Enter again: ")
  
  p2 = random.randint(0, 2)
  p2c = options[p2]

  if (p1 == p2c):
    print("You Tied! The computer chose " + p2c + "!")
  if (p1 == "Rock" and p2c == "Paper"):
    print("You Lost! The computer chose " + p2c + "!")
  if (p1 == "Rock" and p2c == "Scissors"):
    print("You Won! The computer chose " + p2c + "!")
  if (p1 == "Paper" and p2c == "Scissors"):
    print("You Lost! The computer chose " + p2c + "!")
  if (p1 == "Paper" and p2c == "Rock"):
    print("You Won! The computer chose " + p2c + "!")
  if (p1 == "Scissors" and p2c == "Paper"):
    print("You Won! The computer chose " + p2c + "!")
  if (p1 == "Scissors" and p2c == "Rock"):
    print("You Lost! The computer chose " + p2c + "!")
  

play()
