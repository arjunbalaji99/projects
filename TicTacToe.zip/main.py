#create a board, allow people to make moves, check for wins

board = ['-', '-', '-', '-', '-', '-', '-', '-', '-']

def displayboard():
  print(board[0] + '|' + board[1] + '|' + board[2])
  print(board[3] + '|' + board[4] + '|' + board[5])
  print(board[6] + '|' + board[7] + '|' + board[8])

def playgame():
  turn = 1
  while (True):
    displayboard()
    
    if (turn > 2):
       turn = 1

    play(turn)

    if (winplayer1() == True):
      print("Player 1 Wins!")
      break
    if (winplayer2() == True):
      print("Player 2 Wins!")
      break
    if (filled() == True):
      break

    turn += 1



def winplayer1():
  if (board[0] == board[1] == board[2] != '-'):
    return True
  if (board[3] == board[4] == board[5] != '-'):
    return True
  if (board[6] == board[7] == board[8] != '-'):
    return True

  if (board[0] == board[3] == board[6] != '-'):
    return True
  if (board[1] == board[4] == board[7] != '-'):
    return True
  if (board[2] == board[5] == board[8] != '-'):
    return True
  
  if (board[0] == board[4] == board[8] != '-'):
    return True
  if (board[6] == board[4] == board[2] != '-'):
    return True

def winplayer2():
  if (board[0] and board[1] and board[2] != '-'):
    return True
  if (board[3] and board[4] and board[5] != '-'):
    return True
  if (board[6] and board[7] and board[8] != '-'):
    return True

  if (board[0] and board[3] and board[6] != '-'):
    return True
  if (board[1] and board[4] and board[7] != '-'):
    return True
  if (board[2] and board[5] and board[8] != '-'):
    return True
  
  if (board[0] and board[4] and board[8] != '-'):
    return True
  if (board[6] and board[4] and board[2] != '-'):
    return True
  
def play(n):
  if (n == 1):
    while (True):
      l = input("Choose a location 0 - 8: ")
      l = int(l)
      if (board[l] == '-'):
        board[l] = 'x'
        break
      else:
        print("Someone has already played there!")
  if (n == 2):
    while (True):
      l = input("Choose a location 0 - 8: ")
      l = int(l)
      if (board[l] == '-'):
        board[l] = 'o'
        break
      else:
        print("Someone has already played there!")

def filled():
  if (board[0] != '-' and board[3] != '-' and board[6] != '-'
  and board[1] != '-' and board[4] != '-' and board[7] != '-' and
  board[2] != '-' and board[5] != '-' and board[8] != '-'):
    return True

playgame()